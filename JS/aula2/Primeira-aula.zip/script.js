alert("Olá mundo");
alert("Hello world");
alert("Primeira aula");
