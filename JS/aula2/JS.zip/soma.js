let numeroA = Number(prompt("Digite o número A"));
let numeroB = Number(prompt("Digite o número B"));

let resultado = numeroA + numeroB;
alert('O resultado da soma é: ' + resultado);
