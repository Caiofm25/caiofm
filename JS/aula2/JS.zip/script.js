// let nomeCompleto = "Caio\nFerreira\nMonteiro";
// alert(nomeCompleto);

// let a = 10;
// let b = 5;
// let resultado = (a + 2) * (b + 3);

// console.log(resultado);

// let numero = prompt("Digite um número");
// console.log(typeof 10);

// let numeroFalso = '100';
// let numeroVerdadeiro = Number(numeroFalso);

// alert(numeroVerdadeiro);
// console.log(typeof numeroVerdadeiro);
/*

/*
Declarei a variável número

Guardando o número 10
*/

// Declarei a variável "número", guardei o valor 10

// let numero = 10

// Recebe o primeiro número da soma
// let numeroA = Number(prompt("Digite o número A"));

// Recebe o segundo número da soma
// let numeroB = Number(prompt("Digite o número B"));
// console.log(numeroB)

// Guarda o resultado da soma
// let resultado = numeroA + numeroB;
// alert('O resultado da soma é: ' + resultado);

console.log(Math.floor(Math.random() * (20 - 15) + 15));
