let nome = prompt("Qual é o seu nome?");
let sobrenome = prompt("Qual é o seu sobrenome");

let nomeCompleto = nome + " " + sobrenome;
let mensagem = "Seja bem-vinde, " + nomeCompleto + "!";

alert(mensagem);
