// let nomeCompleto = "Caio Ferreira Monteiro";

// let a = 10;
// let b = 3;

// let resultado = a + b;
// console.log(resultado);

// let nome = prompt('Qual é o seu nome?');
// let sobrenome = prompt('Qual é o seu sobrenome?');

// alert(nome);
// alert(sobrenome);

// let nome = prompt("Qual é o seu nome?");
// let sobrenome = prompt("Qual é o seu sobrenome?");

// let numeroAString = prompt("Digite um número");
// let numeroA = Number(numeroAString);

// alert(numeroA * 2);

// let numeroA = Number(prompt("Digite um número"));

// alert(numeroA * 2);
